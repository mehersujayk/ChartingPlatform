from iex import stock
from cmu_112_graphics import *
from datetime import *

tickerSymbol = input()

ticker = stock(tickerSymbol)

stockHigh = int(ticker.getHighestHighLowestLow('20210415')[0])
stockLow = ticker.getHighestHighLowestLow('20210415')[1]
print(stockHigh)
#ticker.plot()


def appStarted(app):
    app.r = app.width/30
    app.graphWidth = 0 + app.width//10
    app.graphBottom = app.height - (app.height//10)
    app.graphTop = 0 + (app.height/10)
    app.graphHeight = app.graphTop - app.graphBottom
    app.increment = int(abs(app.graphHeight // 20))
    highestHighLowestLow = ticker.getHighestHighLowestLow('20210415')
    app.stockHigh = highestHighLowestLow[0]
    app.stockLow = highestHighLowestLow[1]
    app.candleStickWidth = app.width // 200
    app.graphLeft = app.width//10
    app.graphRight = app.width - (app.width//10)


def drawBase(app, canvas):
    stockFont = ("Comic Sans MS", 20, "bold")
    stockName = ticker.getName()
    w = app.width
    h = app.height
    canvas.create_line(0 + (w/10), 0 + (h/10), 0 + (w/10), h - (h/10), width=5)
    canvas.create_line(0 + (w/10), h-(h/10), w - (w/10), h - (h/10), width=5)
    canvas.create_text((w/2) - app.r, 0 + (h/20), text=stockName, font=stockFont)





def keyPressed(app, canvas):
    pass

def mousePressed(app, canvas):
    pass


def getTicks(app):
    #These are a bunch of variables used to calculate the pixel difference
    #per dollar of the stock
    graphDiff = app.graphBottom - app.graphTop
    stockDiff = app.stockHigh - app.stockLow
    pixelDiffPerDollarMove = graphDiff / stockDiff #change this if tkinter can't graph decimals
    OHLCValues = []
    prices = ticker.getPricesDailyOHLC('20210415')

    #calculates the pixel difference for open, high, low, and close
    #and adds them to a list
    for date in prices:
        dollarDiff = prices[date][0] - prices[date][3]
        pixelDiff = pixelDiffPerDollarMove * dollarDiff
        open = app.graphBottom - (prices[date][0] - app.stockLow) * pixelDiffPerDollarMove
        high = app.graphBottom - (prices[date][1] - app.stockLow) * pixelDiffPerDollarMove
        low = app.graphBottom - (prices[date][2] - app.stockLow) * pixelDiffPerDollarMove
        close = app.graphBottom - (prices[date][3] - app.stockLow) * pixelDiffPerDollarMove
        priceLst = [open, high, low, close]
        
            
        OHLCValues.append(priceLst)

    for value in OHLCValues:
        print(value)

    print(len(OHLCValues))
    #return the OHLC values
    return OHLCValues



def drawCandlesticks(app, canvas):
    OHLCValues = getTicks(app)

    # graphDiff = app.graphBottom - app.graphTop
    # stockDiff = app.stockHigh - app.stockLow
    # pixelDiffPerDollarMove = stockDiff / graphDiff #change this if tkinter can't graph decimals
    w = app.width
    h = app.height

    date_format = "%m/%d/%Y"
    a = datetime.strptime('4/15/2021', date_format)
    b = datetime.strptime('11/17/2021', date_format)
    delta = b - a
    numDays = delta.days
    xaxisWidthInPixels = app.graphRight - app.graphLeft
    pixelsPerDay = xaxisWidthInPixels/numDays
    wickPixels = pixelsPerDay / 2
    #drawing a candlestick

    #top wick
    
    
    #body
    #using the Open and Close values from OHLC Values, I created the bodies
    #at the correct places in the chart and moved the candlesticks the perfect
    #amount by calculating the pixels per day in the x direction and adding it
    #to the x coordinate

    #wicks
    #using the high, low, close, and open values, I constructed wicks for the
    #stock that represent how high and how low the price reached before it 
    #it settled at its close price
    for day in range(numDays):
        

        if OHLCValues[day][3] >= OHLCValues[day][0]:

            canvas.create_rectangle((w//10) + (pixelsPerDay * day), 
                                    OHLCValues[day][3],
                                    (w//10) + (pixelsPerDay * day) + pixelsPerDay,
                                    OHLCValues[day][0], 
                                    fill = 'black')
            
            #top wick
            canvas.create_line((w//10) + (pixelsPerDay * (day)) + wickPixels,
                           OHLCValues[day][1], 
                           (w//10) + (pixelsPerDay * (day)) + wickPixels,
                           OHLCValues[day][0])

            #bottom wick
            canvas.create_line((w//10) + (pixelsPerDay * (day)) + wickPixels,
                           OHLCValues[day][3], 
                           (w//10) + (pixelsPerDay * (day)) + wickPixels,
                           OHLCValues[day][2])
        
        if OHLCValues[day][3] < OHLCValues[day][0]:
            canvas.create_rectangle((w//10) + (pixelsPerDay * day), 
                                    OHLCValues[day][3],
                                    (w//10) + (pixelsPerDay * day) + pixelsPerDay,
                                    OHLCValues[day][0], 
                                    fill = 'blue')
            
            #top wick
            canvas.create_line((w//10) + (pixelsPerDay * (day)) + wickPixels,
                           OHLCValues[day][1], 
                           (w//10) + (pixelsPerDay * (day)) + wickPixels,
                           OHLCValues[day][3])
            
            #bottom wick
            canvas.create_line((w//10) + (pixelsPerDay * (day)) + wickPixels,
                           OHLCValues[day][0], 
                           (w//10) + (pixelsPerDay * (day)) + wickPixels,
                           OHLCValues[day][2])

    

    

def drawDashes(app, canvas):
    diff = app.stockHigh - app.stockLow
    pixelsTopBottom = app.graphBottom - app.graphTop
    increment = diff // 21
    

    for x in range(1,21):
        height = app.graphBottom - (x * app.increment) + (app.height//80)
        price = (app.stockLow + (x * increment))

        canvas.create_text(app.graphWidth-(app.width/25),
                           height, text='{:0.2f}'.format(price) )
        
def drawDates(app, canvas):
    date_format = "%m/%d/%Y"
    a = datetime.strptime('4/15/2021', date_format)
    b = datetime.strptime('11/17/2021', date_format)
    delta = b - a
    numDays = delta.days
    xaxisWidthInPixels = app.graphRight - app.graphLeft
    pixelsPerDay = xaxisWidthInPixels/numDays
    daysToNextPrint = numDays // 3
    pixelsToNextPrint = daysToNextPrint * pixelsPerDay

def drawUI(app, canvas):
    w = app.width
    h = app.height
    r = w//4
    canvas.create_rectangle((w//2) + r, h/30, (w//2) + r + (r//2), h/30+(h/20), fill = 'red')
    canvas.create_text((w//2) + r + (r//4), h/30 + (h/60), text='Trade!')
    pass

        
        

def redrawAll(app, canvas):
    drawBase(app, canvas)
    drawDashes(app, canvas)
    drawCandlesticks(app, canvas)
    drawUI(app, canvas)
    pass


runApp(width=800, height=800)


